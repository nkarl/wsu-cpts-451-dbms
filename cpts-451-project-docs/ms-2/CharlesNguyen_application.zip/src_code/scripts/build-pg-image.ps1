docker build -t nkarl/cpts-451-postgres .
docker compose up -d
