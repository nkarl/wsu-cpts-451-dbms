docker exec -it cpts-451-database psql -U postgres -c '\l'
docker exec -it cpts-451-database psql milestone1db postgres -c '\dt'
