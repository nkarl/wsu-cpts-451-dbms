docker exec -it cpts-451-database psql milestone1db postgres -c "SELECT * FROM business;"
