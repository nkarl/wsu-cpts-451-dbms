docker exec -it cpts-451-database psql -U postgres -c '\l'
docker exec -it cpts-451-database psql yelpdb postgres -c '\dt'
